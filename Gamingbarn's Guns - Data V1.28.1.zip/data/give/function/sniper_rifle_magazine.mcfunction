loot give @s loot gbg:items/ammo/standard/sniper_rifle_magazine
