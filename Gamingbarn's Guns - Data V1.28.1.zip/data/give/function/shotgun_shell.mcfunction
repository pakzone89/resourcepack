loot give @s loot gbg:items/ammo/standard/shotgun_shell
