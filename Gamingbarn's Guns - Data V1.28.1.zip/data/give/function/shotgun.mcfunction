loot give @s loot gbg:items/gun/standard/shotgun
