# Playing the different sounds at different distances
$playsound $(sound0) player @a[distance=..26] ~ ~ ~ 20 $(pitch)
$playsound $(sound1) player @a[distance=26.01..60] ~ ~ ~ 20 $(pitch)
$playsound $(sound2) player @a[distance=60.01..128] ~ ~ ~ 20 $(pitch)
$playsound $(sound3) player @a[distance=128.01..256] ~ ~ ~ 20 $(pitch)
# Applying accuracy offset before firing projectile
$execute rotated ~$(pitch_amount) ~$(yaw_amount) run function gbg:gun/shooting_projectile
