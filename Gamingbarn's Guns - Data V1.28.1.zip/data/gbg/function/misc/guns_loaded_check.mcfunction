# This function will fail to load if the enchantment isn't loaded
scoreboard players set check gbg.temp 0
execute store result score check gbg.temp run function gbg:misc/guns_loaded_check2
execute if score check gbg.temp matches 0 run return fail
# If function ran, everything is fine
scoreboard players set are_guns_loaded config.gbg 1
return 1
