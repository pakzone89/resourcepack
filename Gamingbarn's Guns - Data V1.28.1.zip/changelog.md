## GBG V1.28.1

**Updated to Minecraft 26.1**
- Datapack now works on the 26.1 version of Minecraft

**Added All Copper Bars to Raycast Passable List**
- All projectiles can now shoot/pass through the copper bars

